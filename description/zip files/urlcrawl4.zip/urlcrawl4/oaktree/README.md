We can't avoid hardcoding as  just extracting text without mentioning classses will also get all  javascript and other unwanted text nodes. eg(response.xpath('//text()').extract()).

Print was used instead of logger to redirect the result of console into a file. 

PDFs avaialable on this page:https://www.oaktreecapital.com/insights/howard-marks-memos are not accesssible since these are dynamically loaded elements and cannot be selected by traditional selectors eg:a.hyperlinkLeaf.
Hence PDFs from here can't be downloaded.

