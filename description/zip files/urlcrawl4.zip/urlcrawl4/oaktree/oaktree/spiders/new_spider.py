import scrapy
from scrapy.spiders import CrawlSpider, Rule
from scrapy.linkextractors import LinkExtractor
from ..items import OaktreeItem
import requests
from bs4 import BeautifulSoup


class MySpider(CrawlSpider):
    name = 'new'
    denied = scrapy.linkextractors.IGNORED_EXTENSIONS
    scrapy.linkextractors.IGNORED_EXTENSIONS.remove('pdf')

    def __init__(self, *args, **kwargs):
        urls = kwargs.pop('urls', []) 
        if urls:
            self.start_urls = urls.split(',')
            self.rules = [Rule(LinkExtractor(allow=urls.split('://')[1] + '/'),
                      callback='parse_item', follow=True)]
        self.logger.info(self.start_urls)
        super(MySpider, self).__init__(*args, **kwargs)


    def parse_item(self, response):
        if 'pdf' in response.url and self.save_content == 'pdf':
            self.save_pdf(response)
        elif self.save_content == 'text':
            self.save_text(response)
        elif self.save_content == 'text_pdf':
            self.save_pdf(response)
            self.save_text(response)

    def save_pdf(self,response):
        item = OaktreeItem()
        item["file_urls"] = [response.url]
        yield item

    def save_text(self,response):
        text_content = [i.strip() for i in response.xpath('//body//text()').extract()] 
        for text in text_content:
            if text != '':
                self.log('getting text')
                print(text) 
